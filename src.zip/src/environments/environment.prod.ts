export const environment = {
  production: true,
  BASE_URL:"https://investment-app-dot-clinicalfirst.el.r.appspot.com/"
};
