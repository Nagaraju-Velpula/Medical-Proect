export interface Image {
    imageDesciption: string;
    image: string;
  }
  