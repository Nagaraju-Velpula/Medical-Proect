import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popup1',
  templateUrl: './popup1.component.html',
  styleUrls: ['./popup1.component.css']
})
export class Popup1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
